// App.jsx
import React, { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css'; // Import AOS CSS for its animations

import Navbar from './components/Navbar';
import Home from './components/Home'; // Assuming you have a Home component
import About from './components/About'; // Your About component
import Services from './components/Services'; // Assuming you have a Services component
import Dashboard from './components/Dashboard'; // Assuming you have a Dashboard component
import Contact from './components/Contact'; // Assuming you have a Contact component
import Footer from './components/footer'; // Assuming you have a Footer component

function App() {
  useEffect(() => {
    AOS.init({
      duration: 1000, // Animation duration
      once: true,    // Whether animation should happen only once - default
    });
    // You might also want to refresh AOS if components load asynchronously
    // AOS.refresh(); 
  }, []);

  return (
    <div className="bg-white text-gray-800 overflow-x-hidden"> {/* Changed body background to white */}
      <Navbar />
      
      {/*
        These are placeholders for your other sections.
        Ensure they also have unique IDs if you plan to link to them from Navbar.
      */}
      <Home /> 
      <About /> {/* Your About section, correctly placed */}
      <Services />
      <Dashboard />
      <Contact />
      
      <Footer />
    </div>
  );
}

export default App;