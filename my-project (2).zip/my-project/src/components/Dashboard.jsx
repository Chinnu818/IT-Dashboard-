import React from 'react';
import CountUp from 'react-countup';

const stats = [
  { title: 'Users', value: 1204, color: 'bg-indigo-500' },
  { title: 'Uptime (%)', value: 99.99, color: 'bg-stone-800' },
  { title: 'Traffic (visits)', value: 48000, color: 'bg-pink-500' },
  { title: 'Revenue ($)', value: 1061000000, color: 'bg-violet-950' },
  { title: 'Marketing', value: 1204, color: 'bg-rose-500' },
  { title: 'Sales', value: 99.99, color: 'bg-amber-700' },
  { title: 'Support', value: 48000, color: 'bg-blue-800' },
  { title: 'Development', value: 10610000, color: 'bg-lime-700' },

];

const Dashboard = () => {
  return (
    <section id="overview" className="p-6 bg-black text-white">
      <h2 className="text-5xl font-semibold mb-10 text-center text-indigo-300">Company Overview</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {stats.map((stat, i) => (
          <div key={i} className={`rounded-xl p-6 ${stat.color} text-white shadow-md hover:scale-105 transition-transform`}>
            <h3 className="text-lg font-medium">{stat.title}</h3>
            <p className="text-4xl font-bold mt-2">
              <CountUp end={stat.value} duration={3} separator="," decimals={stat.value % 1 !== 0 ? 2 : 0} />
            </p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Dashboard;
