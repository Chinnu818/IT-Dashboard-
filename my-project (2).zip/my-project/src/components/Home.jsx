import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import dashboardImage from '../assets/AI.gif';

const phrases = ['NeuroStack IT', 'AWS', 'Data Security'];

const Home = () => {
  const [text, setText] = useState('');
  const [phraseIndex, setPhraseIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const currentPhrase = phrases[phraseIndex];
    const typingSpeed = isDeleting ? 50 : 120;

    const timeout = setTimeout(() => {
      const updatedText = isDeleting
        ? currentPhrase.substring(0, charIndex - 1)
        : currentPhrase.substring(0, charIndex + 1);
      setText(updatedText);
      setCharIndex((prev) => (isDeleting ? prev - 1 : prev + 1));

      if (!isDeleting && updatedText === currentPhrase) {
        setTimeout(() => setIsDeleting(true), 1000);
      }

      if (isDeleting && updatedText === '') {
        setIsDeleting(false);
        setPhraseIndex((prev) => (prev + 1) % phrases.length);
      }
    }, typingSpeed);

    return () => clearTimeout(timeout);
  }, [charIndex, isDeleting, phraseIndex]);

  return (
    <section
      id="home"
      className="relative w-full h-screen bg-cover bg-center text-white flex items-center justify-center px-6 md:px-12"
      style={{ backgroundImage: `url(${dashboardImage})` }}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-black bg-opacity-70" />

      {/* Text Content */}
      <motion.div
        className="relative z-10 text-center max-w-4xl"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >

        <h1 className="text-5xl md:text-6xl font-bold text-indigo-300 mb-6">
          Future with <span className="text-indigo-400">{text}|</span>
        </h1>

        <p className="text-2xl text-gray-200">
          Empower your IT infrastructure with smart analytics, real-time insights and secure AI systems.
        </p>
      </motion.div>
    </section>
  );
};

export default Home;
