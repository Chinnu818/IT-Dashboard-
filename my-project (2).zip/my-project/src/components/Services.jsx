import React from 'react';

const courses = [
  {
    title: '1. Network & Infrastructure Management',
    description: 'Gain hands-on experience with configuring routers, switches, firewalls, and managing enterprise networks securely.',
  },
  {
    title: '2. System Administration (Linux & Windows)',
    description: 'Master user management, file systems, security policies, shell scripting, and system automation across platforms.',
  },
  {
    title: '3. Cloud Computing (AWS, Azure, GCP)',
    description: 'Learn cloud deployment, scaling, storage, and services with real-world projects using leading cloud platforms.',
  },
  {
    title: '4. Cybersecurity Fundamentals',
    description: 'Understand risk assessment, threat modeling, firewalls, encryption, and defensive strategies to secure IT environments.',
  },
  {
    title: '5. DevOps & CI/CD Pipelines',
    description: 'Implement continuous integration, delivery, monitoring, containerization (Docker), and orchestration (Kubernetes).',
  },
  {
    title: '6. IT Project Management',
    description: 'Explore Agile, Scrum, and ITIL practices for planning, executing, and managing IT projects effectively.',
  },
];

const Services = () => {
  return (
    <section id="services" className="bg-gray-900 text-white py-20 px-6 md:px-12">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold text-indigo-400">OUR SERVICES</h2>
        <p className="text-gray-300 mt-4 max-w-2xl mx-auto">
          Upskill with in-demand IT courses to strengthen your career in infrastructure, security, cloud, and beyond.
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
        {courses.map((course, index) => (
          <div
            key={index}
            className="bg-gray-800 rounded-xl shadow-md p-6 border border-gray-700 hover:scale-105 transition-transform"
          >
            <h3 className="text-xl font-semibold text-indigo-300 mb-2">{course.title}</h3>
            <p className="text-gray-300">{course.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Services;
