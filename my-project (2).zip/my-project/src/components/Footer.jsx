import React from 'react';
import { motion } from 'framer-motion';

const Footer = () => {
  return (
    <footer className="bg-black text-white py-14">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <motion.div
          className="grid grid-cols-1 md:grid-cols-4 gap-8"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          transition={{ staggerChildren: 0.2 }}
        >
          {/* Company Info */}
          <motion.div
            variants={{
              hidden: { opacity: 0, y: 30 },
              visible: { opacity: 1, y: 0 },
            }}
          >
            <h3 className="text-xl font-bold text-indigo-400">IT SERVICES</h3>
            <p className="mt-2 text-sm text-gray-400">
              Empowering businesses through infrastructure management, cloud migration, cybersecurity, and 24/7 IT support tailored to your needs.
            </p>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            variants={{
              hidden: { opacity: 0, y: 30 },
              visible: { opacity: 1, y: 0 },
            }}
          >
            <h4 className="text-lg font-semibold mb-2">Quick Links</h4>
            <ul className="text-sm text-gray-300 space-y-2">
              <li><a href="#home" className="hover:text-indigo-400">Home</a></li>
              <li><a href="#about" className="hover:text-indigo-400">About</a></li>
              <li><a href="#services" className="hover:text-indigo-400">Services</a></li>
              <li><a href="#dashboard" className="hover:text-indigo-400">Dashboard</a></li>
              <li><a href="#contact" className="hover:text-indigo-400">Contact</a></li>
            </ul>
          </motion.div>

          {/* IT Services */}
          <motion.div
            variants={{
              hidden: { opacity: 0, y: 30 },
              visible: { opacity: 1, y: 0 },
            }}
          >
            <h4 className="text-lg font-semibold mb-2">Core IT Services</h4>
            <ul className="text-sm text-gray-300 space-y-2">
              <li>Network Infrastructure</li>
              <li>Cloud Migration</li>
              <li>Cybersecurity Solutions</li>
              <li>IT Consulting</li>
              <li>24/7 Support & Monitoring</li>
            </ul>
          </motion.div>

          {/* Newsletter */}
          <motion.div
            variants={{
              hidden: { opacity: 0, y: 30 },
              visible: { opacity: 1, y: 0 },
            }}
          >
            <h4 className="text-lg font-semibold mb-2">Subscribe for Updates</h4>
            <form className="space-y-3">
              <input
                type="email"
                placeholder="Your email"
                className="w-full p-2 rounded bg-gray-800 text-white border border-gray-700 focus:outline-none"
              />
              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 transition py-2 rounded"
              >
                Subscribe
              </button>
            </form>
          </motion.div>
        </motion.div>

        {/* Social Media Icons */}
        <motion.div
          className="flex justify-center gap-6 mt-10"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          viewport={{ once: true }}
        >
          <a href="https://facebook.com" target="_blank" rel="noreferrer">
            <svg className="w-6 h-6 text-gray-400 hover:text-indigo-400 transition" fill="currentColor" viewBox="0 0 24 24">
              <path d="M22 12.07C22 6.48 17.52 2 12 2S2 6.48 2 12.07C2 17.06 5.66 21.13 10.44 21.9v-6.53h-3.1v-2.6h3.1v-1.98c0-3.1 1.86-4.81 4.7-4.81 1.37 0 2.8.25 2.8.25v3.08h-1.58c-1.56 0-2.04.96-2.04 1.95v2.34h3.48l-.56 2.6h-2.92v6.53C18.34 21.13 22 17.06 22 12.07z" />
            </svg>
          </a>
          <a href="https://twitter.com" target="_blank" rel="noreferrer">
            <svg className="w-6 h-6 text-gray-400 hover:text-indigo-400 transition" fill="currentColor" viewBox="0 0 24 24">
              <path d="M22.46 6c-.77.35-1.6.58-2.46.69a4.26 4.26 0 001.88-2.35 8.48 8.48 0 01-2.7 1.03A4.24 4.24 0 0015.5 4c-2.33 0-4.22 1.9-4.22 4.24 0 .33.04.65.1.96C7.7 8.96 4.48 7.13 2.4 4.24c-.37.63-.58 1.35-.58 2.12 0 1.46.74 2.75 1.87 3.5a4.2 4.2 0 01-1.91-.53v.05c0 2.04 1.45 3.74 3.37 4.13-.36.1-.74.15-1.13.15-.28 0-.55-.03-.81-.07.55 1.73 2.16 3 4.07 3.04A8.5 8.5 0 012 18.57a11.94 11.94 0 006.29 1.84c7.55 0 11.68-6.25 11.68-11.68 0-.18-.01-.36-.02-.54A8.2 8.2 0 0024 4.59a8.47 8.47 0 01-2.54.7z" />
            </svg>
          </a>
          <a href="https://linkedin.com" target="_blank" rel="noreferrer">
            <svg className="w-6 h-6 text-gray-400 hover:text-indigo-400 transition" fill="currentColor" viewBox="0 0 24 24">
              <path d="M4.98 3.5C4.98 4.6 4.07 5.5 2.98 5.5 1.9 5.5 1 4.6 1 3.5S1.9 1.5 2.98 1.5c1.09 0 2 .9 2 2zM1.5 21.5h3v-13h-3v13zM8.5 8.5h2.82v1.79h.04c.39-.74 1.36-1.51 2.8-1.51 2.99 0 3.54 1.97 3.54 4.53v5.19h-3v-4.6c0-1.1-.02-2.51-1.53-2.51-1.53 0-1.77 1.2-1.77 2.43v4.68h-3v-10z" />
            </svg>
          </a>
          <a href="https://github.com" target="_blank" rel="noreferrer">
            <svg className="w-6 h-6 text-gray-400 hover:text-indigo-400 transition" fill="currentColor" viewBox="0 0 24 24">
              <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.48 2 2 6.58 2 12.26c0 4.5 2.87 8.32 6.84 9.67.5.1.68-.22.68-.49v-1.74c-2.78.61-3.37-1.35-3.37-1.35-.46-1.2-1.12-1.52-1.12-1.52-.91-.64.07-.63.07-.63 1.01.07 1.54 1.06 1.54 1.06.89 1.56 2.34 1.11 2.91.84.09-.65.35-1.1.63-1.35-2.22-.26-4.56-1.14-4.56-5.07 0-1.12.39-2.03 1.03-2.74-.1-.26-.45-1.3.1-2.7 0 0 .84-.28 2.75 1.05a9.31 9.31 0 012.5-.35c.85 0 1.71.12 2.5.35 1.91-1.33 2.75-1.05 2.75-1.05.55 1.4.2 2.44.1 2.7.65.71 1.03 1.62 1.03 2.74 0 3.94-2.34 4.8-4.57 5.06.36.31.69.93.69 1.89v2.8c0 .27.18.59.69.49A10.01 10.01 0 0022 12.26C22 6.58 17.52 2 12 2z" />
            </svg>
          </a>
        </motion.div>

        {/* Bottom Bar */}
        <motion.div
          className="mt-8 border-t border-gray-800 pt-6 text-center text-sm text-gray-500"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          viewport={{ once: true }}
        >
          © {new Date().getFullYear()} NeuroStack IT. All rights reserved.
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;
