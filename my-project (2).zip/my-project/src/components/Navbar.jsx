import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import logo from '../assets/logo.png';

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [showLogin, setShowLogin] = useState(false);

  const toggleMenu = () => setMenuOpen(!menuOpen);

  return (
    <>
      {/* Navbar */}
      <nav className="w-full shadow bg-black text-white fixed top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <img className="h-10 w-auto" src={logo} alt="Logo" />
            <span className="text-xl font-bold text-indigo-400">NeuroStack IT</span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-6">
            {['Home', 'About Us', 'Services', 'overview', 'Contact'].map((link) => (
              <a
                key={link}
                href={`#${link.toLowerCase().replace(' ', '')}`}
                className="hover:text-indigo-400 transition duration-300"
              >
                {link}
              </a>
            ))}

            {/* Search */}
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search..."
              className="ml-4 px-3 py-1 rounded-md bg-gray-800 border border-gray-700 text-white focus:outline-none focus:ring focus:ring-indigo-500"
            />

            {/* Login Button */}
            <button
              onClick={() => setShowLogin(true)}
              className="ml-4 px-4 py-1 rounded-md bg-indigo-600 hover:bg-indigo-700 transition"
            >
              Login
            </button>
          </div>

          {/* Mobile Toggle Button */}
          <div className="md:hidden">
            <button onClick={toggleMenu}>
              {menuOpen ? (
                <motion.svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </motion.svg>
              ) : (
                <motion.svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </motion.svg>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {menuOpen && (
            <motion.div
              className="md:hidden bg-gray-900 px-4 pb-6 space-y-4"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              {['Home', 'About Us', 'Services', 'Dashboard', 'Contact'].map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase().replace(' ', '')}`}
                  className="block hover:text-indigo-400 transition"
                >
                  {link}
                </a>
              ))}

              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search..."
                className="w-full px-3 py-2 rounded-md bg-gray-800 border border-gray-600 text-white focus:outline-none focus:ring focus:ring-indigo-500"
              />

              <button
                onClick={() => setShowLogin(true)}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded"
              >
                Login
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Login Modal */}
      <AnimatePresence>
        {showLogin && (
          <motion.div
            className="fixed inset-0 bg-black bg-opacity-70 z-50 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="bg-gray-900 text-white rounded-lg p-6 w-96 shadow-lg relative"
              initial={{ scale: 0.8, y: -30, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.8, y: 20, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <h2 className="text-2xl font-semibold mb-4 text-center text-indigo-400">Login</h2>

              <input
                type="email"
                placeholder="Email"
                className="w-full mb-3 px-4 py-2 rounded bg-gray-800 border border-gray-700 focus:outline-none focus:ring focus:ring-indigo-500"
              />
              <input
                type="password"
                placeholder="Password"
                className="w-full mb-4 px-4 py-2 rounded bg-gray-800 border border-gray-700 focus:outline-none focus:ring focus:ring-indigo-500"
              />

              <button className="w-full bg-indigo-600 hover:bg-indigo-700 py-2 rounded transition">
                Submit
              </button>

              <button
                className="absolute top-2 right-3 text-gray-500 hover:text-red-500 text-xl"
                onClick={() => setShowLogin(false)}
              >
                ✕
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navbar;
