import React from 'react';
import { motion } from 'framer-motion';

const About = () => {
  return (
    <section
      id="aboutus"
      className="py-20 px-6 md:px-12 bg-black text-white"
    >
      <motion.div
        className="max-w-4xl mx-auto text-center border-l-4 border-indigo-500 pl-6"
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
      >
        <h2 className="text-4xl font-extrabold text-indigo-400 mb-4">
          About Our IT Dashboard
        </h2>
        <p className="text-lg text-gray-300 leading-loose">
          Our IT Dashboard is crafted to streamline and monitor all critical IT operations — from performance analytics and security insights to real-time alerts and infrastructure health. Designed with scalability and control in mind, it empowers IT teams to make proactive decisions and maintain business continuity efficiently.
        </p>
      </motion.div>
    </section>
  );
};

export default About;
