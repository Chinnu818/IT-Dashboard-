import React from 'react';
import { motion } from 'framer-motion';

const Contact = () => {
  return (
    <section
      id="contact"
      className="flex flex-col justify-center items-center px-6 md:px-12 bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 text-white py-20"
    >
      <motion.h2
        className="text-4xl font-bold mb-6 text-indigo-400"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        viewport={{ once: true }}
      >
        Contact Us
      </motion.h2>

      <motion.form
        className="flex flex-col gap-4 w-full max-w-md bg-gray-900 p-6 rounded-xl shadow-lg border border-gray-700"
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        viewport={{ once: true }}
      >
        <input
          type="text"
          placeholder="Name"
          className="p-3 border rounded-lg bg-gray-800 border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
        <input
          type="email"
          placeholder="Email"
          className="p-3 border rounded-lg bg-gray-800 border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
        <textarea
          placeholder="Your Message"
          className="p-3 border rounded-lg bg-gray-800 border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
        <button
          type="submit"
          className="bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition transform hover:scale-105"
        >
          Send
        </button>
      </motion.form>
    </section>
  );
};

export default Contact;
